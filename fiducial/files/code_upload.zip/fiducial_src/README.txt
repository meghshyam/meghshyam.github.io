Contents:
1. DetectFiducial: 
	a. Excutable (detectFiducial), 
	b. Source code folder (src), 
	c. Training data folder (trainingData),
	d. libAlgLibShared.so (compiled version of AlgLib) and,
	e. Makefile
2. AlgLib: contains source code of third party library we use for clustering.

Minimum Requirements:
Processor: Intel Core i3, 
RAM: 2 GB
OS: Ubuntu 12.04 (or any compatible version of Linux)
Library: OpenCV 2.4.9

To run our code (on Linux ia64):
1. Go to folder DetectFiducial
2. Set LD_LIBRARY_PATH: export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./
3. Run the executable: ./detectFiducial <input file>

If you are using our code in your work, please cite following paper.
Prasad, M.G., Chandran S., Brown, M.S., "A Motion Blur Resilient Fiducial for Quadcopter Imaging", WACV 2015

Thank you.

