// Code to detect fiducial
// Copyright (C) 2015 Meghshyam Prasad, Sharat Chandran, Michael S. Brown
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
// If you are using our code in your work, please cite following paper.
// Prasad, M.G., Sharat Chandran, Brown, M.S.,
// A Motion Blur Resilient Fiducial for Quadcopter Imaging, WACV 2015

/*
 * GaborFilter.cpp
 *
 *  Created on: Jan 23, 2014
 *      Author: meghshyam
 */

#include "GaborFilter.h"
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv/highgui.h>
#include <math.h>
#include <iostream>
using namespace std;
GaborFilter::GaborFilter() {
	// TODO Auto-generated constructor stub

}

GaborFilter::~GaborFilter() {
	// TODO Auto-generated destructor stub
}

void GaborFilter::filter(Mat &input, Mat &gaborOutput){
	Size ksize(64,64);
	double sigma, theta, lambd, gamma, psi1, psi2;
	int ktype = CV_64F;
	int bw =1;
	lambd  = 8; theta   = 0;
	psi1     = 0; psi2 =  M_PI/2;
	gamma   = 0.5;
	sigma = lambd/M_PI*sqrt(log(2)/2)*(pow(2,bw)+1)/(pow(2,bw)-1);
	Mat final_output;
	Mat inputGray, output[8];
	if(input.channels() >=3 )
		cvtColor(input, inputGray, CV_BGR2GRAY);
	else
		inputGray = input.clone();
	//cout<<"Type of imageo:"<<inputGray.type()<<"\n";

	for(int i=0; i<8; i++)
	{
		Mat output1, output2, magOutput;
		Mat kernel1 = getGaborKernel(ksize,sigma,theta,lambd,gamma,psi1);
		filter2D(inputGray, output1, CV_32F, kernel1);
		Mat kernel2 = getGaborKernel(ksize,sigma,theta,lambd,gamma,psi2);
		filter2D(inputGray, output2, CV_32F, kernel2);
		magnitude(output1, output2, magOutput);
		pow(magOutput, 2, output[i]);
		if(i > 0)
		{
			add(final_output, output[i], final_output);
		}else{
			final_output = output[i];
		}
		theta += 45*M_PI/180;
	}
	pow(final_output, 0.5, final_output);
	double minVal;
	double maxVal;
	Point minLoc;
	Point maxLoc;

	minMaxLoc( final_output, &minVal, &maxVal, &minLoc, &maxLoc );
	final_output = final_output * (1.0/maxVal);
	gaborOutput = final_output > 0.4;
}
