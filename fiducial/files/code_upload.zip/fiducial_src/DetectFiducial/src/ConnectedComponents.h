// Code to detect fiducial
// Copyright (C) 2015 Meghshyam Prasad, Sharat Chandran, Michael S. Brown
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
// If you are using our code in your work, please cite following paper.
// Prasad, M.G., Sharat Chandran, Brown, M.S.,
// A Motion Blur Resilient Fiducial for Quadcopter Imaging, WACV 2015

/*
 * ConnectedComponents.h
 *
 *  Created on: Jan 28, 2014
 *      Author: meghshyam
 */

#ifndef CONNECTEDCOMPONENTS_H_
#define CONNECTEDCOMPONENTS_H_

#include <opencv/cv.h>

int connectedComponents(cv::Mat &img, cv::Mat &labels, int connectivity, int ltype);
int connectedComponentsWithStats(const cv::Mat &img, cv::Mat &labels, cv::Mat &statsv, cv::Mat &centroids, int connectivity, int ltype);
int connectedComponentsWithStats(const cv::Mat &img, cv::Mat &statsv);
//! connected components algorithm output formats

enum { CC_STAT_LEFT   = 0,

       CC_STAT_TOP    = 1,

       CC_STAT_WIDTH  = 2,

       CC_STAT_HEIGHT = 3,

       CC_STAT_AREA   = 4,

       CC_STAT_MAX    = 5

     };


#endif /* CONNECTEDCOMPONENTS_H_ */
